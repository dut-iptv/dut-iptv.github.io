# service.dutiptv.proxy

### About

-Proxy required by the Dut-IPTV addons 

### Thanks

-Matt Huisman for his development of the kodi addons that where used as a base for this addon

-Team Kodi for Kodi