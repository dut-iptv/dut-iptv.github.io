# plugin.video.videoland

### About

-Watch Videoland content from anywhere in the EU

### Features

-Unofficial 3rd Party Videoland plugin for Kodi

-Watch video on demand (VOD) content

-Search Content

### Maximum supported Resolution

- 1080P

### Required

-Subscription to Videoland (not free)

-Kodi 19 or higher with Widevine Support (free)

### Thanks

-Matt Huisman for his development of the kodi addons that where used as a base for this addon

-peak3d for Inputstream Adaptive

-Team Kodi for Kodi